# Chat Premium Application

## Overview

This is a modern chat application built with React and TypeScript that provides an intelligent consultation interface. Users can submit queries and receive AI-powered responses through an external webhook service. The application features a premium dark theme design with a conversational interface optimized for user interaction.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Framework**: shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme variables
- **State Management**: React hooks with TanStack React Query for server state
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Runtime**: Node.js 20 with Express.js server
- **Language**: TypeScript with ESM modules
- **Development**: tsx for development server with hot reload
- **Production**: esbuild for server bundling

### Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL 16 (configured but not actively used)
- **Schema**: User management schema defined in shared directory
- **Storage**: Currently uses in-memory storage with interface for future database integration

## Key Components

### Chat System
- **Chat Interface**: Full-screen conversational UI with message bubbles
- **Message Types**: User messages, assistant responses, and error states
- **Input System**: Auto-resizing textarea with keyboard shortcuts (Enter to send)
- **Loading States**: Visual feedback during AI processing

### UI Components
- **Design System**: Complete shadcn/ui component library
- **Theme**: Custom dark theme with premium styling variables
- **Responsive**: Mobile-first design with adaptive layouts
- **Accessibility**: ARIA compliant components with proper focus management

### External Integration
- **AI Service**: n8n webhook integration for intelligent responses
- **Error Handling**: Comprehensive error states with user-friendly messages
- **Network**: Fetch-based HTTP client with proper error boundaries

## Data Flow

1. **User Input**: User types query in chat input component
2. **Frontend Processing**: Form validation and UI state updates
3. **API Request**: POST request to external n8n webhook with prompt
4. **AI Processing**: External service processes query and returns response
5. **Response Handling**: Frontend receives and displays AI response
6. **State Management**: React Query manages request state and caching
7. **UI Updates**: Messages appear in chat interface with timestamps

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React 18, React DOM, React Query
- **UI Framework**: Radix UI primitives, shadcn/ui components
- **Styling**: Tailwind CSS, class-variance-authority, clsx
- **Database**: Drizzle ORM, @neondatabase/serverless
- **Development**: Vite, TypeScript, tsx, esbuild

### External Services
- **AI Processing**: n8n webhook at oxsr13.app.n8n.cloud
- **Database**: Neon PostgreSQL (configured for future use)
- **Deployment**: Replit with autoscale deployment target

## Deployment Strategy

### Development Environment
- **Platform**: Replit with Node.js 20, web, and PostgreSQL modules
- **Command**: `npm run dev` starts development server on port 5000
- **Hot Reload**: Vite development server with runtime error overlay

### Production Deployment
- **Build Process**: Vite builds client, esbuild bundles server
- **Deployment**: Autoscale deployment on Replit
- **Port Configuration**: Internal port 5000 mapped to external port 80
- **Environment**: Production mode with NODE_ENV=production

### File Structure
```
├── client/           # React frontend application
├── server/           # Express.js backend
├── shared/           # Shared TypeScript schemas
├── migrations/       # Database migrations (future use)
└── dist/            # Production build output
```

## Changelog

```
Changelog:
- June 19, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```