import { cn } from "@/lib/utils";

interface ChatMessageProps {
  content: string;
  role: 'user' | 'assistant';
  isError?: boolean;
  timestamp?: Date;
}

export function ChatMessage({ content, role, isError = false, timestamp }: ChatMessageProps) {
  const isUser = role === 'user';
  
  return (
    <div className={cn("flex", isUser ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "rounded-2xl px-4 py-3 max-w-xs sm:max-w-md lg:max-w-lg xl:max-w-xl",
          isUser
            ? "message-bubble-user"
            : isError
            ? "message-bubble-error"
            : "message-bubble-assistant"
        )}
      >
        <div className="text-sm leading-relaxed whitespace-pre-wrap">
          {content}
        </div>
        {timestamp && (
          <div className={cn(
            "text-xs mt-1 opacity-70",
            isUser ? "text-right" : "text-left"
          )}>
            {timestamp.toLocaleTimeString('es-ES', {
              hour: '2-digit',
              minute: '2-digit'
            })}
          </div>
        )}
      </div>
    </div>
  );
}
