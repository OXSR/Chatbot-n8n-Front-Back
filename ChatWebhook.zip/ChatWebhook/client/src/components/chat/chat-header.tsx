interface ChatHeaderProps {}

export function ChatHeader({}: ChatHeaderProps) {
  return (
    <header className="flex-shrink-0 border-b border-border px-6 py-6">
      <div className="text-center">
        <h1 className="text-xl font-semibold text-foreground">Chat Premium</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Envía tu consulta y recibe respuestas inteligentes
        </p>
      </div>
    </header>
  );
}
