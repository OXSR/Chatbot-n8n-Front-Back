interface WelcomeMessageProps {}

export function WelcomeMessage({}: WelcomeMessageProps) {
  return (
    <div className="flex justify-center">
      <div className="text-center max-w-md">
        <div className="text-4xl mb-4">💬</div>
        <h2 className="text-lg font-medium text-foreground mb-2">
          ¡Bienvenido a Chat Premium!
        </h2>
        <p className="text-muted-foreground text-sm leading-relaxed">
          Escribe tu consulta en el campo de texto y presiona "Ejecutar Consulta" 
          para obtener una respuesta inteligente.
        </p>
      </div>
    </div>
  );
}
