import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

interface ChatInputProps {
  onSubmit: (prompt: string) => void;
  isLoading: boolean;
  disabled?: boolean;
}

export function ChatInput({ onSubmit, isLoading, disabled = false }: ChatInputProps) {
  const [prompt, setPrompt] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedPrompt = prompt.trim();
    if (!trimmedPrompt || isLoading || disabled) return;
    
    onSubmit(trimmedPrompt);
    setPrompt("");
    
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setPrompt(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 128) + 'px';
  };

  useEffect(() => {
    // Focus input on mount
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, []);

  return (
    <div className="flex-shrink-0 border-t border-border px-6 py-4">
      <form onSubmit={handleSubmit} className="flex items-end space-x-3">
        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            value={prompt}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            placeholder="Escribe tu consulta aquí..."
            rows={1}
            disabled={disabled}
            className={cn(
              "resize-none bg-secondary border-border rounded-xl",
              "text-foreground placeholder-muted-foreground",
              "focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent",
              "transition-all duration-200 min-h-[48px] max-h-32",
              "scrollbar-hide"
            )}
          />
        </div>
        <Button
          type="submit"
          disabled={!prompt.trim() || isLoading || disabled}
          className={cn(
            "bg-accent hover:bg-accent/90 disabled:bg-accent/50",
            "disabled:cursor-not-allowed text-white font-medium",
            "px-6 py-3 rounded-xl transition-all duration-200 whitespace-nowrap",
            "focus:outline-none focus:ring-2 focus:ring-accent/50",
            "min-h-[48px]"
          )}
        >
          {isLoading ? "Procesando..." : "Ejecutar Consulta"}
        </Button>
      </form>
    </div>
  );
}
