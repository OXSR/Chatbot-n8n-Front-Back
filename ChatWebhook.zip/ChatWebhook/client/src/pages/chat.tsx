import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { ChatHeader } from "@/components/chat/chat-header";
import { WelcomeMessage } from "@/components/chat/welcome-message";
import { ChatMessage } from "@/components/chat/chat-message";
import { ChatInput } from "@/components/chat/chat-input";
import { useToast } from "@/hooks/use-toast";
import { scrollToBottom } from "@/lib/utils";

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  isError?: boolean;
}

interface WebhookResponse {
  respuesta: string;
}

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoadingVisible, setIsLoadingVisible] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const sendMessageMutation = useMutation({
    mutationFn: async (prompt: string): Promise<WebhookResponse> => {
      const response = await fetch('https://oxsr13.app.n8n.cloud/webhook/1116aeb3-d7c6-4ced-82d2-ca8662a46692', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.respuesta) {
        throw new Error('Formato de respuesta inválido');
      }

      return data;
    },
    onSuccess: (data) => {
      setIsLoadingVisible(false);
      addMessage(data.respuesta, 'assistant');
    },
    onError: (error) => {
      setIsLoadingVisible(false);
      console.error('Error:', error);
      
      const errorMessage = error instanceof Error 
        ? error.message 
        : 'Error desconocido';
      
      toast({
        title: "Error",
        description: "Error al procesar la consulta. Intenta nuevamente.",
        variant: "destructive",
      });
      
      addMessage(
        'Lo siento, hubo un error al procesar tu consulta. Por favor, intenta nuevamente.',
        'assistant',
        true
      );
    },
  });

  const addMessage = (content: string, role: 'user' | 'assistant', isError = false) => {
    const newMessage: Message = {
      id: `${Date.now()}-${Math.random()}`,
      content,
      role,
      timestamp: new Date(),
      isError,
    };

    setMessages(prev => [...prev, newMessage]);
  };

  const handleSubmit = (prompt: string) => {
    // Add user message
    addMessage(prompt, 'user');
    
    // Show loading state
    setIsLoadingVisible(true);
    
    // Send to webhook
    sendMessageMutation.mutate(prompt);
  };

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (chatContainerRef.current) {
      scrollToBottom(chatContainerRef.current);
    }
  }, [messages, isLoadingVisible]);

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto bg-background">
      <ChatHeader />
      
      <div
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto px-6 py-6 space-y-6 scrollbar-hide min-h-0"
      >
        {messages.length === 0 && <WelcomeMessage />}
        
        {messages.map((message) => (
          <ChatMessage
            key={message.id}
            content={message.content}
            role={message.role}
            isError={message.isError}
            timestamp={message.timestamp}
          />
        ))}

        {isLoadingVisible && (
          <div className="flex justify-start">
            <div className="bg-secondary rounded-2xl px-4 py-3 max-w-xs">
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse"></div>
                  <div 
                    className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse" 
                    style={{ animationDelay: '0.2s' }}
                  ></div>
                  <div 
                    className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse" 
                    style={{ animationDelay: '0.4s' }}
                  ></div>
                </div>
                <span className="text-sm text-muted-foreground">Procesando...</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <ChatInput
        onSubmit={handleSubmit}
        isLoading={sendMessageMutation.isPending}
      />
    </div>
  );
}
